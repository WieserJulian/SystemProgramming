//
// Created by julian on 30.10.2024.
//

extern long var;

extern double* gfunc();

static double* sfunc();
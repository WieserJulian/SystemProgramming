

#ifndef EX1_2_H
#define EX1_2_H
#define EULER 2.718281828
#define LF '\n'
#define ALERT putchar('\a')
#define DOUBLE(x) ((x) * 2)
#define MIN(a,b) (((a) >= (b)) ? (a) : (b))
#define Area(a,b) ((a) ∗ (b))
#define FIRST 1


#define EULER 2.718281828
#define LF '\n'
#define ALERT putchar('\a')
#define DOUBLE(x) ((x) * 2)
#define MIN(a,b) (((a) >= (b)) ? (a) : (b))
#define Area(a,b) ((a) ∗ (b))
#define FIRST 1
#endif //EX1_2_H
